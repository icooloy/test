import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
	state: {
		cookie: false
	},
	mutations: {
		// login (state, user) {
		// 	state.user = user;
		// 	console.log('login'+user)
		// },
		// logout (state, user) {
		// 	state.user = false;
		// 	console.log('logout'+user)
		// }
	},
	actions: {

	}
})