export default {
	request: {
		baseURL: 'http://120.77.181.138/userback/',
		type: 'get',
		token: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.cutZ+HOT1mvx9Rcf71jUhg==.eyJleHAiOjE1NTQyODcxNDIyMTEsInBheWxvYWQiOiJcIjMyNzY4XzE1NTQyODcxNDIyMTBcIiJ9.dSB9iTewEBQEL09vOQbXDbdN1XToHQ3fEfrrorVnuq4',
	},
	appRequest: false,
};
