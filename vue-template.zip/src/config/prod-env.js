export default {
	request: {
		baseURL: 'http://120.77.181.138/userback/',
		type: 'get',
		token: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.m+HTC2R0uhCJIFBVOcVvOA==.eyJleHAiOjE1NTQyMjE1OTA5MjAsInBheWxvYWQiOiJcIjMyNzY4XzE1NTQyMjE1OTA5MjBcIiJ9.MPiL33Z4AlYvOd-LgBkQ8IfZsR2GrRYcs-xbixkyz_E',
	},
	appRequest: true,
};
