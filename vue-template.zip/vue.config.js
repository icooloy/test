module.exports = {
	baseUrl: './',
	devServer: {
        host: '0.0.0.0',
        disableHostCheck: true,
    }
};